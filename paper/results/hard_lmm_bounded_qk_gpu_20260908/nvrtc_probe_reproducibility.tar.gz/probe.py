#!/usr/bin/env python3
"""Tiny CUDA probe for source-89 normalized duration likelihoods."""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
import math
import os
import subprocess
import sys
from pathlib import Path
from typing import Any


EXPECTED_REVISION = "89cd700c28dd169cd59bfccbd694ef8967bac823"


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def normal_cdf(value: float) -> float:
    return 0.5 * math.erfc(-value / math.sqrt(2.0))


def normal_sf(value: float) -> float:
    return 0.5 * math.erfc(value / math.sqrt(2.0))


def finite_nested(value: Any) -> bool:
    if isinstance(value, dict):
        return all(finite_nested(item) for item in value.values())
    if isinstance(value, list):
        return all(finite_nested(item) for item in value)
    if isinstance(value, float):
        return math.isfinite(value)
    return True


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source-root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--nvrtc", type=Path, required=True)
    parser.add_argument("--nvrtc-builtins", type=Path, required=True)
    args = parser.parse_args()

    source_root = args.source_root.resolve()
    sys.path.insert(0, str(source_root))

    import torch

    from models.TPPs.CountAwareTPP import (
        SharedTimeCountModel,
        TIME_HEAD_MODE_HETEROSCEDASTIC_LOGNORMAL_DURATION,
    )
    from paper.scripts import run_hard_lmm_frozen_lognormal_duration as likelihood

    source_revision = subprocess.run(
        ["git", "-C", str(source_root), "rev-parse", "HEAD"],
        check=True,
        capture_output=True,
        text=True,
    ).stdout.strip()
    if source_revision != EXPECTED_REVISION:
        raise RuntimeError(f"Unexpected source revision: {source_revision}")
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA is unavailable")

    torch.manual_seed(20260908)
    cpu_model = SharedTimeCountModel(
        hidden_dim=4,
        train_log_mean=1.0,
        time_head_mode=TIME_HEAD_MODE_HETEROSCEDASTIC_LOGNORMAL_DURATION,
        time_scale=2.0,
        time_initial_location=0.15,
        time_initial_scale=0.75,
        time_sigma_floor=1e-3,
    ).cpu()
    with torch.no_grad():
        cpu_model.v_t.weight.copy_(
            torch.tensor([[0.15, -0.07, 0.03, 0.11]], dtype=torch.float32)
        )
        cpu_model.time_scale_weight.weight.copy_(
            torch.tensor([[0.05, 0.02, -0.04, 0.01]], dtype=torch.float32)
        )
        cpu_model.b_t.fill_(0.12)

    cuda_model = copy.deepcopy(cpu_model).cuda()

    base_hidden = torch.tensor(
        [[0.20, -0.10, 0.30, 0.05]], dtype=torch.float32
    )
    continuous_dt = torch.tensor(
        [0.75, 1.0, 2.0, 7.0, 30.0], dtype=torch.float32
    )
    continuous_hidden = base_hidden.repeat(continuous_dt.numel(), 1)
    continuous_censor = torch.zeros(continuous_dt.numel(), dtype=torch.bool)

    integer_dt = torch.tensor([1.0, 2.0, 3.0, 30.0], dtype=torch.float32)
    integer_hidden = base_hidden.repeat(integer_dt.numel(), 1)
    integer_censor = torch.tensor([False, False, False, True])

    mass_dt = torch.arange(1, 62, dtype=torch.float32)
    mass_hidden = base_hidden.repeat(mass_dt.numel(), 1)
    mass_censor = torch.zeros(mass_dt.numel(), dtype=torch.bool)
    mass_censor[-1] = True

    def outputs(model: SharedTimeCountModel, device: torch.device) -> dict[str, torch.Tensor]:
        return {
            "continuous": likelihood.proper_time_log_likelihood(
                model,
                continuous_hidden.to(device),
                continuous_dt.to(device),
                is_right_censored=continuous_censor.to(device),
                observation_likelihood_mode=likelihood.OBSERVATION_LIKELIHOOD_CONTINUOUS,
            ),
            "integer": likelihood.proper_time_log_likelihood(
                model,
                integer_hidden.to(device),
                integer_dt.to(device),
                is_right_censored=integer_censor.to(device),
                observation_likelihood_mode=likelihood.OBSERVATION_LIKELIHOOD_POSITIVE_INTEGER,
            ),
            "mass": likelihood.proper_time_log_likelihood(
                model,
                mass_hidden.to(device),
                mass_dt.to(device),
                is_right_censored=mass_censor.to(device),
                observation_likelihood_mode=likelihood.OBSERVATION_LIKELIHOOD_POSITIVE_INTEGER,
            ),
        }

    cpu_output = outputs(cpu_model, torch.device("cpu"))
    cuda_output = outputs(cuda_model, torch.device("cuda:0"))
    torch.cuda.synchronize()

    output_differences = {
        name: float((cuda_output[name].cpu() - cpu_output[name]).abs().max().item())
        for name in cpu_output
    }

    # Exercise backward through both density and discrete/censored paths.
    grad_hidden_cpu = base_hidden.repeat(integer_dt.numel(), 1).requires_grad_(True)
    grad_hidden_cuda = grad_hidden_cpu.detach().cuda().requires_grad_(True)

    def backward_probe(
        model: SharedTimeCountModel,
        hidden: torch.Tensor,
        device: torch.device,
    ) -> tuple[float, dict[str, list[float]]]:
        model.zero_grad(set_to_none=True)
        log_cont = likelihood.proper_time_log_likelihood(
            model,
            hidden,
            torch.tensor([0.75, 1.0, 7.0, 30.0], dtype=torch.float32, device=device),
            is_right_censored=torch.zeros(4, dtype=torch.bool, device=device),
            observation_likelihood_mode=likelihood.OBSERVATION_LIKELIHOOD_CONTINUOUS,
        )
        log_integer = likelihood.proper_time_log_likelihood(
            model,
            hidden,
            integer_dt.to(device),
            is_right_censored=integer_censor.to(device),
            observation_likelihood_mode=likelihood.OBSERVATION_LIKELIHOOD_POSITIVE_INTEGER,
        )
        loss = -(log_cont.mean() + log_integer.mean())
        loss.backward()
        gradients = {
            "hidden": hidden.grad.detach().cpu().double().reshape(-1).tolist(),
            "v_t.weight": model.v_t.weight.grad.detach().cpu().double().reshape(-1).tolist(),
            "b_t": model.b_t.grad.detach().cpu().double().reshape(-1).tolist(),
            "w_raw": model.w_raw.grad.detach().cpu().double().reshape(-1).tolist(),
            "time_scale_weight.weight": model.time_scale_weight.weight.grad.detach().cpu().double().reshape(-1).tolist(),
        }
        return float(loss.detach().cpu().item()), gradients

    cpu_loss, cpu_gradients = backward_probe(
        cpu_model, grad_hidden_cpu, torch.device("cpu")
    )
    cuda_loss, cuda_gradients = backward_probe(
        cuda_model, grad_hidden_cuda, torch.device("cuda:0")
    )
    torch.cuda.synchronize()

    gradient_differences: dict[str, float] = {}
    gradient_nonzero: dict[str, bool] = {}
    for name in cpu_gradients:
        left = torch.tensor(cpu_gradients[name], dtype=torch.float64)
        right = torch.tensor(cuda_gradients[name], dtype=torch.float64)
        gradient_differences[name] = float((left - right).abs().max().item())
        gradient_nonzero[name] = bool((right.abs() > 0.0).any().item())

    # Independent scalar reference for the fixed hidden row.
    with torch.no_grad():
        location, sigma, _ = cpu_model._lognormal_time_terms(
            base_hidden, torch.ones(1)
        )
    location_value = float(location.item())
    sigma_value = float(sigma.item())
    scale_value = float(cpu_model.time_scale)

    def z(value: float) -> float:
        return (math.log(value) - math.log(scale_value) - location_value) / sigma_value

    manual_continuous = []
    for duration in continuous_dt.double().tolist():
        standardized = z(duration)
        manual_continuous.append(
            -0.5 * standardized * standardized
            - math.log(sigma_value)
            - math.log(duration)
            - 0.5 * math.log(2.0 * math.pi)
        )
    manual_first_bin = math.log(normal_cdf(z(1.5)))
    manual_insta_survival = math.log(normal_sf(z(29.5)))

    manual_mass = normal_cdf(z(1.5))
    for duration in range(2, 61):
        manual_mass += normal_cdf(z(duration + 0.5)) - normal_cdf(z(duration - 0.5))
    manual_mass += normal_sf(z(60.5))

    source_mass = float(torch.exp(cuda_output["mass"]).sum().cpu().item())
    source_first_bin = float(cuda_output["integer"][0].cpu().item())
    source_insta_survival = float(cuda_output["integer"][-1].cpu().item())
    continuous_manual_max_difference = max(
        abs(actual - expected)
        for actual, expected in zip(
            cuda_output["continuous"].detach().cpu().tolist(), manual_continuous
        )
    )

    maps = Path("/proc/self/maps").read_text(encoding="utf-8").splitlines()
    loaded_nvrtc_paths = sorted(
        {
            line.rsplit(maxsplit=1)[-1]
            for line in maps
            if "libnvrtc" in line and "/" in line.rsplit(maxsplit=1)[-1]
        }
    )

    selected_libraries = []
    for path in (args.nvrtc, args.nvrtc_builtins):
        resolved = path.resolve()
        selected_libraries.append(
            {
                "path": str(path),
                "resolved_path": str(resolved),
                "bytes": resolved.stat().st_size,
                "sha256": sha256_file(resolved),
            }
        )

    checks = {
        "source_revision_exact": source_revision == EXPECTED_REVISION,
        "cuda_available": bool(torch.cuda.is_available()),
        "all_outputs_float64": all(value.dtype == torch.float64 for value in cuda_output.values()),
        "all_outputs_finite": all(bool(torch.isfinite(value).all().item()) for value in cuda_output.values()),
        "all_gradients_finite": finite_nested(cuda_gradients),
        "all_gradient_groups_nonzero": all(gradient_nonzero.values()),
        "cpu_cuda_output_max_abs_le_1e_10": max(output_differences.values()) <= 1e-10,
        "cpu_cuda_loss_abs_le_1e_10": abs(cuda_loss - cpu_loss) <= 1e-10,
        "cpu_cuda_gradient_max_abs_le_5e_6": max(gradient_differences.values()) <= 5e-6,
        "continuous_manual_max_abs_le_1e_10": continuous_manual_max_difference <= 1e-10,
        "taxi_first_bin_manual_abs_le_1e_10": abs(source_first_bin - manual_first_bin) <= 1e-10,
        "instacart_30_survival_manual_abs_le_1e_10": abs(source_insta_survival - manual_insta_survival) <= 1e-10,
        "integer_mass_abs_error_le_1e_12": abs(source_mass - 1.0) <= 1e-12,
        "manual_integer_mass_abs_error_le_1e_12": abs(manual_mass - 1.0) <= 1e-12,
        "nvrtc_and_builtins_loaded": any("libnvrtc.so.13" in item for item in loaded_nvrtc_paths)
        and any("libnvrtc-builtins.so.13.0" in item for item in loaded_nvrtc_paths),
    }

    report = {
        "schema_version": 1,
        "probe": "source89_normalized_duration_cuda_nvrtc_recovery",
        "status": "pass" if all(checks.values()) else "fail",
        "source": {
            "root": str(source_root),
            "revision": source_revision,
            "likelihood_module": str(Path(likelihood.__file__).resolve()),
            "likelihood_module_sha256": sha256_file(Path(likelihood.__file__).resolve()),
        },
        "runtime": {
            "python": sys.executable,
            "torch": torch.__version__,
            "torch_cuda": torch.version.cuda,
            "cuda_device": torch.cuda.get_device_name(0),
            "cuda_capability": list(torch.cuda.get_device_capability(0)),
            "environment": {
                name: os.environ.get(name)
                for name in (
                    "LD_LIBRARY_PATH",
                    "TORCH_KERNEL_CACHE_PATH",
                    "PYTORCH_KERNEL_CACHE_PATH",
                    "OMP_NUM_THREADS",
                    "MKL_NUM_THREADS",
                    "OPENBLAS_NUM_THREADS",
                    "POLARS_MAX_THREADS",
                    "PYTHONNOUSERSITE",
                )
            },
            "selected_nvrtc_libraries": selected_libraries,
            "loaded_nvrtc_paths_from_proc_maps": loaded_nvrtc_paths,
        },
        "numerics": {
            "cpu_cuda_output_max_abs_by_path": output_differences,
            "cpu_cuda_output_worst_max_abs": max(output_differences.values()),
            "cpu_loss": cpu_loss,
            "cuda_loss": cuda_loss,
            "cpu_cuda_loss_abs": abs(cuda_loss - cpu_loss),
            "cpu_cuda_gradient_max_abs_by_group": gradient_differences,
            "cpu_cuda_gradient_worst_max_abs": max(gradient_differences.values()),
            "cuda_gradient_nonzero_by_group": gradient_nonzero,
            "continuous_manual_max_abs": continuous_manual_max_difference,
            "taxi_first_bin_log_probability": source_first_bin,
            "taxi_first_bin_manual_log_probability": manual_first_bin,
            "taxi_first_bin_manual_abs": abs(source_first_bin - manual_first_bin),
            "instacart_code_30_log_survival": source_insta_survival,
            "instacart_code_30_manual_log_survival": manual_insta_survival,
            "instacart_code_30_manual_abs": abs(source_insta_survival - manual_insta_survival),
            "integer_probability_mass_codes_1_to_60_plus_survival_60_5": source_mass,
            "integer_probability_mass_abs_error": abs(source_mass - 1.0),
            "manual_integer_probability_mass": manual_mass,
            "manual_integer_probability_mass_abs_error": abs(manual_mass - 1.0),
            "location": location_value,
            "sigma": sigma_value,
            "time_scale": scale_value,
        },
        "checks": checks,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    return 0 if report["status"] == "pass" else 1


if __name__ == "__main__":
    raise SystemExit(main())
