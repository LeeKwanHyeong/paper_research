#!/usr/bin/env python3
"""Hash source-89 B/FULL/BOUNDED synthetic CUDA results and gradients."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path


EXPECTED_REVISION = "89cd700c28dd169cd59bfccbd694ef8967bac823"


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source-root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--environment-label", required=True)
    args = parser.parse_args()

    source_root = args.source_root.resolve()
    sys.path.insert(0, str(source_root))

    import torch

    from simple_lab_test.search.common.runner import canonical_state_dict_sha256
    from simple_lab_test.search.tests.test_count_aware_titan_bounded_qk import (
        build_triplet,
        objective,
        sample_batch,
    )

    revision = subprocess.run(
        ["git", "-C", str(source_root), "rev-parse", "HEAD"],
        check=True,
        capture_output=True,
        text=True,
    ).stdout.strip()
    if revision != EXPECTED_REVISION:
        raise RuntimeError(f"Unexpected source revision: {revision}")
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA is unavailable")

    models = build_triplet(seed=42, device="cuda", hidden_dim=64)
    roles = ("B", "FULL", "BOUNDED")
    batch = sample_batch("cuda")
    role_results = {}
    for role, model in zip(roles, models):
        model.train()
        model.zero_grad(set_to_none=True)
        torch.manual_seed(719)
        result = objective(model, *batch)
        result["joint_loss"].sum().backward()
        torch.cuda.synchronize()

        output_tensors = {
            name: value.detach().cpu().contiguous()
            for name, value in result.items()
            if isinstance(value, torch.Tensor)
        }
        gradient_tensors = {
            name: parameter.grad.detach().cpu().contiguous()
            for name, parameter in model.named_parameters()
            if parameter.grad is not None
        }
        role_results[role] = {
            "output_canonical_sha256": canonical_state_dict_sha256(output_tensors),
            "parameter_gradient_canonical_sha256": canonical_state_dict_sha256(gradient_tensors),
            "output_tensor_count": len(output_tensors),
            "gradient_tensor_count": len(gradient_tensors),
            "joint_loss_sum": float(result["joint_loss"].detach().sum().cpu().item()),
            "time_loss_sum": float(result["time_loss"].detach().sum().cpu().item()),
            "quantity_train_loss_sum": float(result["quantity_train_loss"].detach().sum().cpu().item()),
            "all_outputs_finite": all(bool(torch.isfinite(value).all()) for value in output_tensors.values()),
            "all_gradients_finite": all(bool(torch.isfinite(value).all()) for value in gradient_tensors.values()),
        }

    maps = Path("/proc/self/maps").read_text(encoding="utf-8").splitlines()
    nvidia_paths = sorted(
        {
            line.rsplit(maxsplit=1)[-1]
            for line in maps
            if "/site-packages/nvidia/" in line
            and "/" in line.rsplit(maxsplit=1)[-1]
        }
    )
    report = {
        "schema_version": 1,
        "probe": "source89_cuda_environment_parity",
        "environment_label": args.environment_label,
        "source_revision": revision,
        "runtime": {
            "python": sys.executable,
            "torch": torch.__version__,
            "torch_cuda": torch.version.cuda,
            "cuda_device": torch.cuda.get_device_name(0),
            "ld_library_path": os.environ.get("LD_LIBRARY_PATH"),
            "nvidia_loaded_paths_from_proc_maps": nvidia_paths,
        },
        "roles": role_results,
        "checks": {
            "source_revision_exact": revision == EXPECTED_REVISION,
            "cuda_available": bool(torch.cuda.is_available()),
            "all_role_outputs_finite": all(item["all_outputs_finite"] for item in role_results.values()),
            "all_role_gradients_finite": all(item["all_gradients_finite"] for item in role_results.values()),
        },
        "script_sha256": sha256_file(Path(__file__).resolve()),
    }
    report["status"] = "pass" if all(report["checks"].values()) else "fail"
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return 0 if report["status"] == "pass" else 1


if __name__ == "__main__":
    raise SystemExit(main())
